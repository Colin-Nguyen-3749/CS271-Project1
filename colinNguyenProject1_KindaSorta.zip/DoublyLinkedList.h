//========================================================
// CS 271
// Fall 2025
// DoublyLinkedList.h
// This file contains the DoublyLinkedList class declaration.  
// This is similar to your 173 Linked List project.
// But there are key differences! Review the assignment document
// carefully.
//========================================================

#include <iostream>
#include <string>
#include <sstream>
#include <stdlib.h>

#ifndef LIST_H
#define LIST_H

template <class T> 
class DoublyLinkedList
{
	public:
							DoublyLinkedList		(  );
							DoublyLinkedList		( const DoublyLinkedList<T>& mylist );
							~DoublyLinkedList		(  );
	DoublyLinkedList<T>		operator=				( const DoublyLinkedList<T>& mylist );
	void					append					( const T& item	);
	T&						operator[]				( int index );
	void					insert					( const T& item, int index );
	void					remove					( int index );
	DoublyLinkedList<T>		operator+				( const DoublyLinkedList<T>& mylist ) const;
	int						length					(  ) const;
	bool					isEmpty					(  ) const;
	void					clear					(  );
	void 					selectionSort			(  );
	void 					insertionSort			(  );
	void 					mergeSort 				(  );
	void 					mergeSortCall			( DoublyLinkedList<T>& myList, int p, int r );
	void 					merge					( DoublyLinkedList<T>& myList, int p, int q, int r );
	void 					quickSort				( void );
	void 					quickSortCall			( DoublyLinkedList<T>& myList, int p, int r );
	int 					partition				( DoublyLinkedList<T>& myList, int p, int r );
	
	// Returns a string representation of the list to make testing easier
	std::string 			to_string				(  ) const {
		std::stringstream s;

		Node* ptr = nullptr;

		if (head != nullptr){
			s << head -> val;
			ptr = head -> next;
		}

		while(ptr != nullptr) {
			s << " " << ptr -> val;
			ptr = ptr -> next;
		}

		return s.str();
	}; 

	private:
		// Private members you will need, at minimum: 
		// 1. a struct representing a Node
		// 		(Hint: what did a Node struct look like for a singly linked list? 
		// 			what needs to change for a doubly linked list?)
		// 2. a pointer to the first Node in the list (head)
		// 3. a pointer to the last Node in the list (tail)
		// Fill in other private members as needed 

		void reallocate(void);

		struct Node
		{
			T		val;
			Node* 	next;
			Node*	prev;
		};
		
		int 	size;
		Node*	head;		
		Node*	tail;

};


#include "DoublyLinkedList.cpp"

#endif